# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['hatenamd2md']
entry_points = \
{'console_scripts': ['hatenamd2md = hatenamd2md:main']}

setup_kwargs = {
    'name': 'hatenamd2md',
    'version': '0.1.0',
    'description': 'Convert Hatena Blog article written in Markdown mode to Markdown',
    'long_description': None,
    'author': 'shallovv',
    'author_email': 'miomio.ll.8507@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
